	//JQuery functions for dynamic validation
	
	
	//OPTIMIZATION NOT YET IMPLEMENTED FOR FUNCTIONS
	
	//UserID listener
	$(document).ready(function(){
		$("#userIDfield").change(function(){
			if($("#uid").val().length ===0){
				$(this).animate({backgroundColor: "pink"}, 1000);
				$("#userID").animate({backgroundColor: "pink"}, 1000);
				disableSubmit();
			}else{
				$(this).animate({backgroundColor: "white"}, 1000);
				$("#userID").animate({backgroundColor: "white"}, 1000);				
			}
		});		
	});
	//Name listener
	$(document).ready(function(){
		$("#namefield").change(function(){
			if($("#nme").val().length ===0){
				$(this).animate({backgroundColor: "pink"}, 1000);
				$("#name").animate({backgroundColor: "pink"}, 1000);
				disableSubmit();
			}else{
				$(this).animate({backgroundColor: "white"}, 1000);
				$("#name").animate({backgroundColor: "white"}, 1000);				
			}
		});		
	});
	//Password Listener
	//addressed both password and retype password fields
	$(document).ready(function(){
		$("#passwordfield").change(function(){
			if($("#pss").val()!=$("#rps").val()){
				$(this).animate({backgroundColor: "red"}, 1000);
				$("#password").animate({backgroundColor: "red"}, 1000);
				$("#pwrfield").animate({backgroundColor: "red"}, 1000);
				$("#pwr").animate({backgroundColor: "red"}, 1000);				
				disableSubmit(); 
			}else if($("#pss").val().length ===0){
				$(this).animate({backgroundColor: "pink"}, 1000);
				$("#password").animate({backgroundColor: "pink"}, 1000);
				$("#pwrfield").animate({backgroundColor: "pink"}, 1000);
				$("#pwr").animate({backgroundColor: "pink"}, 1000);				
				disableSubmit(); 
			}else{
				$(this).animate({backgroundColor: "white"}, 1000);
				$("#password").animate({backgroundColor: "white"}, 1000);				
				$("#pwrfield").animate({backgroundColor: "white"}, 1000);
				$("#pwr").animate({backgroundColor: "white"}, 1000);	
			}
		});		
	});
	//retype password listener
	//addressed both password and retype password fields
	$(document).ready(function(){
		$("#pwrfield").change(function(){
			if($("#pss").val()!=$("#rps").val()){
				$(this).animate({backgroundColor: "red"}, 1000);
				$("#password").animate({backgroundColor: "red"}, 1000);
				$("#pwrfield").animate({backgroundColor: "red"}, 1000);
				$("#pwr").animate({backgroundColor: "red"}, 1000);				
				disableSubmit(); 
			}else if($("#rps").val().length ===0){
				$(this).animate({backgroundColor: "pink"}, 1000);
				$("#pwr").animate({backgroundColor: "pink"}, 1000);
				$("#passwordfield").animate({backgroundColor: "white"}, 1000);
				$("#password").animate({backgroundColor: "white"}, 1000);
			}else{
				$(this).animate({backgroundColor: "white"}, 1000);
				$("#pwr").animate({backgroundColor: "white"}, 1000);				
				$("#passwordfield").animate({backgroundColor: "white"}, 1000);
				$("#password").animate({backgroundColor: "white"}, 1000);
			}
		});
	});
	//listener for email address field
	$(document).ready(function(){
		$("#emaddfield").change(function(){
			if(!validEmail($("#emd").val())){
				$(this).animate({backgroundColor: "red"}, 1000);
				$("#emadd").animate({backgroundColor: "red"}, 1000);			
			}
			else if($("#emd").val().length ===0){
				$(this).animate({backgroundColor: "pink"}, 1000);
				$("#emadd").animate({backgroundColor: "pink"}, 1000);
			}else{
				$(this).animate({backgroundColor: "white"}, 1000);
				$("#emadd").animate({backgroundColor: "white"}, 1000);				
			}
		});
	});
	$(document).ready(function(){
		$("input").focusout(formReady);
	});
	$(document).ready(function(){
		$("input").keyup(formReady);
	});
	function disableSubmit(){
		$("submitButton").attr("disabled", true);
	}

	/*	
		Regex variable borrowed from 
		http://stackoverflow.com/questions/46155/validate-email-address-in-javascript
	*/
	function validEmail(string){
	    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(string);
	}
	/*Temporary work around comparing elements to enable submit task*/
	function formReady(){
		if($("#userID").css('backgroundColor')==$(".row").css('backgroundColor')
		&& $("#nme").val().length >= 1
		&& $("#pss").val()==$("#rps").val()
		&& validEmail($("#emd").val())){
				$("#submitButton").attr("disabled", false);
			}
	}