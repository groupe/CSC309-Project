<a style="float:left;" href=""><img src="images\header\titleBanner.png"/></a>
<a style="float:right;margin-right:10px;" href="authenticate.html"><h5>Sign in</h5></a>
<a style="float:right;margin-right:10px;" href="register.html"><h5>Register</h5></a>