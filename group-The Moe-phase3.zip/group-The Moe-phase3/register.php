<?php 
$id=$_POST['uid'];
$name=$_POST['nme'];
$hashedPassword=sha1($_POST['pss']);
$emadd=$_POST['emd'];


$host= 'localhost';
$login = 'root';
$pass = '012345678m';
$db = 'pwpschema';

if($_POST['pss']==$_POST['rps'] && strlen($emadd)>6){

$con=mysql_connect($host, $login, $pass) or die(mysql_error());
mysql_select_db($db, $con) or die(mysql_error());

$IDquery=mysql_query("SELECT * FROM user WHERE userID='". $id ."'", $con);
$numrows=mysql_num_rows($IDquery);

if($numrows==0){
	$result=mysql_query("INSERT INTO account (ID, password) VALUES ('".$id."','".$hashedPassword."')", $con);
	if($result==false){
		die(mysql_error());
	}
	$result=mysql_query("INSERT INTO user (userID, name, emadd) VALUES ('".$id."','".$name."','".$emadd."')", $con);
	if($result==false){
		die(mysql_error());
	}
	mysql_close($con);
	echo 'done';
}else{
	echo 'WTF1'; 
}
}else{
	echo 'WTF2';
}

?>