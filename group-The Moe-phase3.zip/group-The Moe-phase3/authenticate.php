

<?php
//Main login script
$hashpass=sha1($_POST['password']);
$id=$_POST['ID'];


$host= 'localhost';
$login = 'root';
$pass = '012345678m';
$db = 'pwpschema';

$con=mysql_connect($host, $login, $pass) or die(mysql_error());
mysql_select_db($db, $con) or die(mysql_error());

$query= "SELECT ID FROM account WHERE ID='".$id."' AND password='".$hashpass."'";
$result=mysql_query($query, $con);
//Log in if query returns a valid match for hash password and userID
if(mysql_num_rows($result)==1){
	echo 'LOGGED IN';
}else{
	header("Location: authenticate.html");
	echo 'Invalid username or password';
}


?>