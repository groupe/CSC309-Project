CREATE TABLE account(
ID varchar(12) NOT NULL,
password varchar(45) NOT NULL,
PRIMARY KEY(ID));

CREATE TABLE administrator(
adminID varchar(12) NOT NULL REFERENCES account(ID),
PRIMARY KEY(adminID));

CREATE TABLE user(
userID varchar(12) NOT NULL REFERENCES account(ID),
name char(20) DEFAULT 'none',
emadd varchar(20) NOT NULL,
description char(20),
joinedEvents varchar(20) REFERENCES event(ID),
PRIMARY KEY(userID));

CREATE TABLE userScore(
userID varchar(12) NOT NULL REFERENCES user(userID),
scoreID varchar(12) NOT NULL,
score int,
title char(20),
PRIMARY KEY (userID, scoreID));

CREATE TABLE rating(
rater varchar(12) NOT NULL REFERENCES user(userID),
rated varchar(20) NOT NULL REFERENCES event(eventID),
rating int NOT NULL,
PRIMARY KEY(rater, rated));

CREATE TABLE event(
userID varchar(12) NOT NULL REFERENCES user(userID),
eventID varchar(20) NOT NULL,
title char(20) NOT NULL,
activeDate int NOT NULL,
rating int,
attendants varchar(12) REFERENCES user(userID),
description char(20),
PRIMARY KEY(eventID));

CREATE TABLE sysvar(
varID varchar(20) NOT NULL,
adminID varchar(12) NOT NULL REFERENCES administrator(adminID),
minUserEvent int,
minUserScoreEvent int,
minUserGap int,
PRIMARY KEY(varID));

