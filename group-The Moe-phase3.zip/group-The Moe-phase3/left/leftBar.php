<div style="background-color:black; width:200px; height:1000px; float:left; clear:left;">

</div>